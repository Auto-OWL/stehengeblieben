# stehengeblieben.de — MVP Setup Guide

## Was du hast

Eine vollständige React-App mit:
- **Startseite** — Hero, How-it-works, Featured Vehicles, Dealer CTA
- **Fahrzeug-Übersicht** — mit Filtern (Marke, Kraftstoff, Preis, Sortierung)
- **Fahrzeug-Detailseite** — Specs, Preisanzeige, Anfrage-Formular
- **Händler-Registrierung** — Formular mit Bestätigung
- **Fahrzeug-Upload** — komplettes Formular inkl. Foto-Upload
- **Admin-Bereich** — Fahrzeuge/Händler freischalten, Anfragen sehen

---

## Schritt-für-Schritt Setup

### 1. Supabase Datenbank einrichten

1. Gehe zu **supabase.com** → dein Projekt öffnen
2. Links im Menü: **SQL Editor**
3. Kopiere den kompletten Inhalt aus `supabase-schema.sql`
4. Klicke **Run** — das erstellt alle Tabellen und Regeln automatisch

### 2. Supabase API Keys holen

1. In Supabase: **Settings** → **API**
2. Kopiere:
   - **Project URL** (sieht aus wie: `https://xxxxx.supabase.co`)
   - **anon public key** (langer String)

### 3. GitHub Repository erstellen

1. Gehe zu **github.com** → **New repository**
2. Name: `stehengeblieben`
3. Public oder Private — egal
4. **Create repository**

### 4. Code hochladen

Lade den gesamten `stehengeblieben`-Ordner als ZIP auf GitHub hoch:

1. Im neuen Repository: klicke **uploading an existing file**
2. Ziehe alle Dateien rein (WICHTIG: auch die versteckten wie `.gitignore`)
3. Commit: "Initial MVP"

**Oder per Terminal (wenn installiert):**
```bash
cd stehengeblieben
git init
git add .
git commit -m "Initial MVP"
git remote add origin https://github.com/DEIN_USERNAME/stehengeblieben.git
git push -u origin main
```

### 5. Vercel deployment

1. Gehe zu **vercel.com** → **New Project**
2. Wähle dein `stehengeblieben` GitHub Repository
3. Framework: **Create React App** (wird automatisch erkannt)
4. **Vor dem Deploy** — Environment Variables hinzufügen:
   - `REACT_APP_SUPABASE_URL` → deine Supabase Project URL
   - `REACT_APP_SUPABASE_ANON_KEY` → dein Supabase anon key
5. **Deploy** klicken

Nach ~2 Minuten ist die Seite live unter einer `vercel.app` URL.

### 6. Eigene Domain verbinden

1. In Vercel: **Settings** → **Domains**
2. `stehengeblieben.de` eingeben
3. Vercel zeigt dir DNS-Einträge die du bei deinem Domain-Anbieter eintragen musst
4. Nach 24h ist die Domain aktiv

---

## Admin-Bereich

Erreichbar unter: `deine-domain.de/admin`

Standard-Passwort: `stehengeblieben2025`

**WICHTIG:** Ändere das Passwort in `src/pages/Admin.js` Zeile 5 bevor du live gehst:
```js
const ADMIN_PASSWORD = 'dein-sicheres-passwort'
```

---

## Was der MVP kann

| Feature | Status |
|---|---|
| Fahrzeuge anzeigen (mit Demo-Daten) | ✅ |
| Fahrzeuge filtern & sortieren | ✅ |
| Fahrzeug-Detailseite | ✅ |
| Anfrage-Formular (Käufer → Händler) | ✅ |
| Händler-Registrierung | ✅ |
| Fahrzeug-Upload mit Fotos | ✅ |
| Admin: freischalten / ablehnen | ✅ |
| Admin: als verkauft markieren | ✅ |
| Admin: Anfragen einsehen | ✅ |
| Echte Daten via Supabase | ✅ |
| Mobile-responsive | ✅ |

## Was noch fehlt (Phase 2)

- Händler-Login (aktuell: E-Mail als Identifikation)
- E-Mail-Benachrichtigungen bei Anfragen
- Erweiterte Bildergalerie
- Fahrzeug-Vergleich
- SEO-Optimierung
- Impressum / Datenschutz (PFLICHT vor Go-Live!)

---

## Nächste Schritte

1. **Sofort:** Supabase Schema ausführen + Vercel deployment
2. **Woche 1:** Erste 3-5 Händler ansprechen, Fahrzeuge einstellen
3. **Woche 2:** Erste Käufer-Anfragen generieren (Social Media Post mit echtem Deal)
4. **Woche 3-4:** Feedback sammeln, iterieren

---

*Bei Fragen oder Problemen: Schreib Claude — ich bin dabei.*
