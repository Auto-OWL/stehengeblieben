import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import './index.css'

import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Home from './pages/Home'
import Vehicles from './pages/Vehicles'
import VehicleDetail from './pages/VehicleDetail'
import DealerRegister from './pages/DealerRegister'
import DealerUpload from './pages/DealerUpload'
import Admin from './pages/Admin'

export default function App() {
  return (
    <Router>
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/fahrzeuge" element={<Vehicles />} />
          <Route path="/fahrzeuge/:id" element={<VehicleDetail />} />
          <Route path="/haendler/registrieren" element={<DealerRegister />} />
          <Route path="/haendler/upload" element={<DealerUpload />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </main>
      <Footer />
    </Router>
  )
}
