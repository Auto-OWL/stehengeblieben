import React from 'react'
import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer style={{
      background: 'var(--black)',
      color: 'var(--gray-400)',
      padding: '48px 24px 32px',
      marginTop: 80,
    }}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: 40,
          marginBottom: 48,
        }}>
          <div>
            <div style={{ marginBottom: 16 }}>
              <span style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', color: 'var(--white)' }}>stehen</span>
              <span style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', color: 'var(--red)' }}>geblieben</span>
              <span style={{ fontSize: '0.75rem', color: 'var(--gray-400)', marginLeft: 3 }}>.de</span>
            </div>
            <p style={{ fontSize: '0.85rem', lineHeight: 1.7, maxWidth: 240 }}>
              Neufahrzeuge mit Tageszulassung. Bis zu 30% unter Listenpreis. Direkt vom Händler.
            </p>
          </div>

          <div>
            <h4 style={{ color: 'var(--white)', fontWeight: 600, marginBottom: 16, fontSize: '0.9rem' }}>Für Käufer</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <Link to="/fahrzeuge" style={{ fontSize: '0.85rem', transition: 'color 0.2s' }}
                onMouseEnter={e => e.target.style.color = 'var(--white)'}
                onMouseLeave={e => e.target.style.color = 'var(--gray-400)'}>
                Alle Fahrzeuge
              </Link>
              <Link to="/fahrzeuge?fuel=Elektro" style={{ fontSize: '0.85rem', transition: 'color 0.2s' }}
                onMouseEnter={e => e.target.style.color = 'var(--white)'}
                onMouseLeave={e => e.target.style.color = 'var(--gray-400)'}>
                Elektrofahrzeuge
              </Link>
            </div>
          </div>

          <div>
            <h4 style={{ color: 'var(--white)', fontWeight: 600, marginBottom: 16, fontSize: '0.9rem' }}>Für Händler</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <Link to="/haendler/registrieren" style={{ fontSize: '0.85rem', transition: 'color 0.2s' }}
                onMouseEnter={e => e.target.style.color = 'var(--white)'}
                onMouseLeave={e => e.target.style.color = 'var(--gray-400)'}>
                Jetzt registrieren
              </Link>
              <Link to="/haendler/upload" style={{ fontSize: '0.85rem', transition: 'color 0.2s' }}
                onMouseEnter={e => e.target.style.color = 'var(--white)'}
                onMouseLeave={e => e.target.style.color = 'var(--gray-400)'}>
                Fahrzeug einstellen
              </Link>
            </div>
          </div>

          <div>
            <h4 style={{ color: 'var(--white)', fontWeight: 600, marginBottom: 16, fontSize: '0.9rem' }}>Rechtliches</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {['Impressum', 'Datenschutz', 'AGB'].map(item => (
                <a key={item} href="#" style={{ fontSize: '0.85rem', transition: 'color 0.2s' }}
                  onMouseEnter={e => e.target.style.color = 'var(--white)'}
                  onMouseLeave={e => e.target.style.color = 'var(--gray-400)'}>
                  {item}
                </a>
              ))}
            </div>
          </div>
        </div>

        <div style={{
          borderTop: '1px solid rgba(255,255,255,0.08)',
          paddingTop: 24,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: 12,
          fontSize: '0.8rem',
        }}>
          <span>© 2025 stehengeblieben.de — Alle Rechte vorbehalten</span>
          <span style={{ color: 'var(--gray-600)' }}>Made in Deutschland 🇩🇪</span>
        </div>
      </div>
    </footer>
  )
}
