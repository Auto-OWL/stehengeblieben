import React, { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => setMenuOpen(false), [location])

  return (
    <nav style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
      background: scrolled ? 'rgba(10,10,10,0.97)' : '#0a0a0a',
      backdropFilter: scrolled ? 'blur(12px)' : 'none',
      borderBottom: scrolled ? '1px solid rgba(255,255,255,0.08)' : '1px solid transparent',
      transition: 'all 0.3s ease',
      padding: '0 24px',
    }}>
      <div style={{
        maxWidth: 1200, margin: '0 auto',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        height: 64,
      }}>
        {/* Logo */}
        <Link to="/" style={{ display: 'flex', alignItems: 'baseline', gap: 2 }}>
          <span style={{
            fontFamily: 'var(--font-display)',
            fontSize: '1.6rem',
            color: 'var(--white)',
            letterSpacing: '0.02em',
            lineHeight: 1,
          }}>
            stehen
          </span>
          <span style={{
            fontFamily: 'var(--font-display)',
            fontSize: '1.6rem',
            color: 'var(--red)',
            letterSpacing: '0.02em',
            lineHeight: 1,
          }}>
            geblieben
          </span>
          <span style={{
            fontFamily: 'var(--font-body)',
            fontSize: '0.75rem',
            color: 'var(--gray-400)',
            marginLeft: 4,
            fontWeight: 400,
          }}>.de</span>
        </Link>

        {/* Desktop Nav */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 32 }} className="desktop-nav">
          <NavLink to="/fahrzeuge">Alle Fahrzeuge</NavLink>
          <NavLink to="/haendler/registrieren">Als Händler mitmachen</NavLink>
          <Link to="/haendler/upload" className="btn-primary" style={{ padding: '9px 20px', fontSize: '0.85rem' }}>
            Fahrzeug einstellen
          </Link>
        </div>

        {/* Mobile Hamburger */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'none' }}
          className="hamburger"
        >
          <div style={{ width: 24, display: 'flex', flexDirection: 'column', gap: 5 }}>
            {[0,1,2].map(i => (
              <span key={i} style={{
                height: 2, background: 'var(--white)', borderRadius: 2,
                transition: '0.3s ease',
                transformOrigin: 'center',
              }} />
            ))}
          </div>
        </button>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div style={{
          background: '#0a0a0a', padding: '16px 24px 24px',
          borderTop: '1px solid rgba(255,255,255,0.08)',
          display: 'flex', flexDirection: 'column', gap: 16,
        }}>
          <Link to="/fahrzeuge" style={{ color: 'var(--white)', fontWeight: 500 }}>Alle Fahrzeuge</Link>
          <Link to="/haendler/registrieren" style={{ color: 'var(--white)', fontWeight: 500 }}>Als Händler mitmachen</Link>
          <Link to="/haendler/upload" className="btn-primary" style={{ textAlign: 'center' }}>Fahrzeug einstellen</Link>
        </div>
      )}

      <style>{`
        @media (max-width: 768px) {
          .desktop-nav { display: none !important; }
          .hamburger { display: flex !important; }
        }
      `}</style>
    </nav>
  )
}

function NavLink({ to, children }) {
  const location = useLocation()
  const active = location.pathname === to
  return (
    <Link to={to} style={{
      color: active ? 'var(--white)' : 'var(--gray-400)',
      fontWeight: 500,
      fontSize: '0.9rem',
      transition: 'color 0.2s',
    }}
    onMouseEnter={e => e.target.style.color = 'var(--white)'}
    onMouseLeave={e => e.target.style.color = active ? 'var(--white)' : 'var(--gray-400)'}
    >
      {children}
    </Link>
  )
}
