import React from 'react'
import { Link } from 'react-router-dom'

export default function VehicleCard({ vehicle }) {
  const {
    id, brand, model, variant, year, mileage,
    list_price, sale_price, discount_percent,
    fuel_type, images, expires_at
  } = vehicle

  const daysLeft = expires_at
    ? Math.ceil((new Date(expires_at) - new Date()) / (1000 * 60 * 60 * 24))
    : null

  const urgent = daysLeft !== null && daysLeft <= 30

  return (
    <Link to={`/fahrzeuge/${id}`} style={{ display: 'block', textDecoration: 'none' }}>
      <div style={{
        background: 'white',
        borderRadius: 'var(--radius-lg)',
        overflow: 'hidden',
        border: '1px solid var(--gray-200)',
        transition: 'transform 0.2s ease, box-shadow 0.2s ease',
        cursor: 'pointer',
      }}
      onMouseEnter={e => {
        e.currentTarget.style.transform = 'translateY(-4px)'
        e.currentTarget.style.boxShadow = 'var(--shadow-lg)'
      }}
      onMouseLeave={e => {
        e.currentTarget.style.transform = 'translateY(0)'
        e.currentTarget.style.boxShadow = 'none'
      }}
      >
        {/* Image */}
        <div style={{ position: 'relative', aspectRatio: '16/10', background: 'var(--gray-100)', overflow: 'hidden' }}>
          {images && images.length > 0 ? (
            <img
              src={images[0]}
              alt={`${brand} ${model}`}
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
          ) : (
            <div style={{
              width: '100%', height: '100%',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'var(--gray-400)', fontSize: '0.85rem',
            }}>
              Kein Foto
            </div>
          )}

          {/* Discount Badge */}
          <div style={{
            position: 'absolute', top: 12, left: 12,
            background: 'var(--red)',
            color: 'white',
            fontFamily: 'var(--font-display)',
            fontSize: '1.1rem',
            padding: '4px 10px',
            borderRadius: 3,
            letterSpacing: '0.04em',
          }}>
            -{discount_percent}%
          </div>

          {/* Urgency Badge */}
          {urgent && (
            <div style={{
              position: 'absolute', top: 12, right: 12,
              background: 'var(--black)',
              color: 'white',
              fontSize: '0.72rem',
              fontWeight: 600,
              padding: '4px 8px',
              borderRadius: 3,
              letterSpacing: '0.04em',
            }}>
              ⏱ Noch {daysLeft} Tage
            </div>
          )}
        </div>

        {/* Content */}
        <div style={{ padding: '16px 18px 20px' }}>
          <div style={{ marginBottom: 4 }}>
            <span style={{
              fontFamily: 'var(--font-display)',
              fontSize: '1.25rem',
              color: 'var(--black)',
              letterSpacing: '0.02em',
            }}>
              {brand} {model}
            </span>
          </div>

          {variant && (
            <div style={{ fontSize: '0.85rem', color: 'var(--gray-600)', marginBottom: 10 }}>
              {variant}
            </div>
          )}

          {/* Tags */}
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 14 }}>
            <span className="badge badge-gray">{year}</span>
            {fuel_type && <span className="badge badge-gray">{fuel_type}</span>}
            <span className="badge badge-gray">{mileage.toLocaleString('de-DE')} km</span>
            <span className="badge badge-dark">Tageszulassung</span>
          </div>

          {/* Pricing */}
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
            <span style={{
              fontFamily: 'var(--font-display)',
              fontSize: '1.6rem',
              color: 'var(--red)',
              letterSpacing: '0.02em',
            }}>
              {Number(sale_price).toLocaleString('de-DE')} €
            </span>
            <span style={{
              fontSize: '0.85rem',
              color: 'var(--gray-400)',
              textDecoration: 'line-through',
            }}>
              {Number(list_price).toLocaleString('de-DE')} €
            </span>
          </div>

          <div style={{ fontSize: '0.8rem', color: 'var(--gray-400)', marginTop: 4 }}>
            Sie sparen {(Number(list_price) - Number(sale_price)).toLocaleString('de-DE')} €
          </div>
        </div>
      </div>
    </Link>
  )
}
