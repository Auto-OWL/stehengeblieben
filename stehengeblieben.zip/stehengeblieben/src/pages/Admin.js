import React, { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

const ADMIN_PASSWORD = 'stehengeblieben2025'

export default function Admin() {
  const [authed, setAuthed] = useState(false)
  const [pw, setPw] = useState('')
  const [vehicles, setVehicles] = useState([])
  const [dealers, setDealers] = useState([])
  const [inquiries, setInquiries] = useState([])
  const [tab, setTab] = useState('vehicles')
  const [loading, setLoading] = useState(false)

  async function load() {
    setLoading(true)
    const [{ data: v }, { data: d }, { data: i }] = await Promise.all([
      supabase.from('vehicles').select('*').order('created_at', { ascending: false }),
      supabase.from('dealers').select('*').order('created_at', { ascending: false }),
      supabase.from('inquiries').select('*').order('created_at', { ascending: false }),
    ])
    setVehicles(v || [])
    setDealers(d || [])
    setInquiries(i || [])
    setLoading(false)
  }

  async function approveVehicle(id) {
    await supabase.from('vehicles').update({ approved: true }).eq('id', id)
    load()
  }

  async function rejectVehicle(id) {
    await supabase.from('vehicles').delete().eq('id', id)
    load()
  }

  async function markSold(id) {
    await supabase.from('vehicles').update({ sold: true }).eq('id', id)
    load()
  }

  async function approveDealer(id) {
    await supabase.from('dealers').update({ approved: true }).eq('id', id)
    load()
  }

  if (!authed) return (
    <div style={{ paddingTop: 64, minHeight: '100vh', background: 'var(--black)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ background: 'white', padding: 40, borderRadius: 'var(--radius-lg)', width: '100%', maxWidth: 360 }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', marginBottom: 24 }}>ADMIN LOGIN</h1>
        <input type="password" placeholder="Passwort" value={pw} onChange={e => setPw(e.target.value)}
          style={{ width: '100%', padding: '11px 14px', border: '1.5px solid var(--gray-200)', borderRadius: 'var(--radius)', fontSize: '0.95rem', marginBottom: 14 }}
          onKeyDown={e => { if (e.key === 'Enter' && pw === ADMIN_PASSWORD) { setAuthed(true); load() } }}
        />
        <button className="btn-primary" style={{ width: '100%', justifyContent: 'center', padding: 13 }}
          onClick={() => { if (pw === ADMIN_PASSWORD) { setAuthed(true); load() } else alert('Falsches Passwort') }}>
          Anmelden
        </button>
      </div>
    </div>
  )

  const pending_v = vehicles.filter(v => !v.approved)
  const approved_v = vehicles.filter(v => v.approved && !v.sold)
  const sold_v = vehicles.filter(v => v.sold)
  const pending_d = dealers.filter(d => !d.approved)

  return (
    <div style={{ paddingTop: 64, minHeight: '100vh', background: 'var(--gray-100)' }}>
      <div style={{ background: 'var(--black)', padding: '32px 24px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', color: 'var(--white)' }}>ADMIN</h1>
          <div style={{ display: 'flex', gap: 20 }}>
            {[
              { key: 'vehicles', label: `Fahrzeuge (${pending_v.length} neu)` },
              { key: 'dealers', label: `Händler (${pending_d.length} neu)` },
              { key: 'inquiries', label: `Anfragen (${inquiries.length})` },
            ].map(t => (
              <button key={t.key} onClick={() => setTab(t.key)} style={{
                background: tab === t.key ? 'var(--red)' : 'transparent',
                color: 'white', border: '1px solid rgba(255,255,255,0.2)',
                padding: '8px 16px', borderRadius: 'var(--radius)',
                cursor: 'pointer', fontSize: '0.85rem', fontWeight: 600,
              }}>
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '32px 24px' }}>
        {loading && <div style={{ textAlign: 'center', padding: 40 }}>Lade...</div>}

        {/* Vehicles Tab */}
        {tab === 'vehicles' && !loading && (
          <div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', marginBottom: 20 }}>
              FAHRZEUGE — {pending_v.length} ausstehend, {approved_v.length} aktiv, {sold_v.length} verkauft
            </h2>
            {vehicles.map(v => (
              <div key={v.id} style={{
                background: 'white', border: '1px solid var(--gray-200)',
                borderRadius: 'var(--radius-lg)', padding: '20px 24px',
                marginBottom: 12, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12,
                borderLeft: v.approved ? (v.sold ? '4px solid var(--gray-400)' : '4px solid #22c55e') : '4px solid var(--red)',
              }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: '1.05rem' }}>{v.brand} {v.model} {v.variant}</div>
                  <div style={{ fontSize: '0.85rem', color: 'var(--gray-600)', marginTop: 3 }}>
                    {v.year} · {v.fuel_type} · {Number(v.sale_price).toLocaleString('de-DE')} € ({v.discount_percent}% Nachlass)
                  </div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--gray-400)', marginTop: 2 }}>
                    Eingestellt: {new Date(v.created_at).toLocaleDateString('de-DE')}
                    {v.approved && !v.sold && ' · ✅ Freigegeben'}
                    {v.sold && ' · 🏁 Verkauft'}
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  {!v.approved && (
                    <>
                      <button onClick={() => approveVehicle(v.id)} style={{ background: '#22c55e', color: 'white', border: 'none', padding: '8px 16px', borderRadius: 'var(--radius)', cursor: 'pointer', fontWeight: 600, fontSize: '0.85rem' }}>
                        Freigeben
                      </button>
                      <button onClick={() => rejectVehicle(v.id)} style={{ background: '#ef4444', color: 'white', border: 'none', padding: '8px 16px', borderRadius: 'var(--radius)', cursor: 'pointer', fontWeight: 600, fontSize: '0.85rem' }}>
                        Ablehnen
                      </button>
                    </>
                  )}
                  {v.approved && !v.sold && (
                    <button onClick={() => markSold(v.id)} style={{ background: 'var(--black)', color: 'white', border: 'none', padding: '8px 16px', borderRadius: 'var(--radius)', cursor: 'pointer', fontWeight: 600, fontSize: '0.85rem' }}>
                      Als verkauft markieren
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Dealers Tab */}
        {tab === 'dealers' && !loading && (
          <div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', marginBottom: 20 }}>
              HÄNDLER — {dealers.length} gesamt, {pending_d.length} ausstehend
            </h2>
            {dealers.map(d => (
              <div key={d.id} style={{
                background: 'white', border: '1px solid var(--gray-200)',
                borderRadius: 'var(--radius-lg)', padding: '20px 24px', marginBottom: 12,
                display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12,
                borderLeft: d.approved ? '4px solid #22c55e' : '4px solid var(--red)',
              }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: '1.05rem' }}>{d.company_name}</div>
                  <div style={{ fontSize: '0.85rem', color: 'var(--gray-600)', marginTop: 3 }}>
                    {d.contact_name} · {d.email} · {d.phone} · {d.city}
                  </div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--gray-400)', marginTop: 2 }}>
                    Registriert: {new Date(d.created_at).toLocaleDateString('de-DE')}
                    {d.approved && ' · ✅ Freigegeben'}
                  </div>
                </div>
                {!d.approved && (
                  <button onClick={() => approveDealer(d.id)} style={{ background: '#22c55e', color: 'white', border: 'none', padding: '8px 16px', borderRadius: 'var(--radius)', cursor: 'pointer', fontWeight: 600, fontSize: '0.85rem' }}>
                    Freigeben
                  </button>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Inquiries Tab */}
        {tab === 'inquiries' && !loading && (
          <div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem', marginBottom: 20 }}>
              ANFRAGEN — {inquiries.length} gesamt
            </h2>
            {inquiries.map(i => (
              <div key={i.id} style={{
                background: 'white', border: '1px solid var(--gray-200)',
                borderRadius: 'var(--radius-lg)', padding: '20px 24px', marginBottom: 12,
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
                  <div>
                    <div style={{ fontWeight: 700 }}>{i.buyer_name}</div>
                    <div style={{ fontSize: '0.85rem', color: 'var(--gray-600)', marginTop: 3 }}>
                      {i.buyer_email} · {i.buyer_phone}
                    </div>
                    {i.message && <div style={{ fontSize: '0.85rem', marginTop: 8, color: 'var(--gray-800)', fontStyle: 'italic' }}>"{i.message}"</div>}
                  </div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--gray-400)', textAlign: 'right' }}>
                    {new Date(i.created_at).toLocaleDateString('de-DE')}<br />
                    Fahrzeug-ID: {i.vehicle_id?.slice(0, 8)}...
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
