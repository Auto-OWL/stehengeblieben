import React, { useState } from 'react'
import { supabase } from '../lib/supabase'

export default function DealerRegister() {
  const [form, setForm] = useState({ company_name: '', contact_name: '', email: '', phone: '', city: '' })
  const [sent, setSent] = useState(false)
  const [sending, setSending] = useState(false)
  const [error, setError] = useState(null)

  async function handleSubmit(e) {
    e.preventDefault()
    setSending(true)
    setError(null)
    const { error } = await supabase.from('dealers').insert({ ...form, approved: false })
    setSending(false)
    if (error) setError('Fehler beim Senden. Bitte versuche es erneut.')
    else setSent(true)
  }

  return (
    <div style={{ paddingTop: 64 }}>
      <div style={{ background: 'var(--black)', padding: '56px 24px' }}>
        <div style={{ maxWidth: 600, margin: '0 auto', textAlign: 'center' }}>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(2.5rem, 7vw, 4rem)', color: 'var(--white)', marginBottom: 16 }}>
            ALS HÄNDLER<br /><span style={{ color: 'var(--red)' }}>MITMACHEN</span>
          </h1>
          <p style={{ color: 'var(--gray-400)', lineHeight: 1.7 }}>
            Langzeitsteher weg, Kapital frei. Du zahlst nur wenn wir verkaufen — kein Abo, kein Risiko.
          </p>
        </div>
      </div>

      {/* Benefits */}
      <div style={{ background: 'var(--gray-100)', padding: '48px 24px' }}>
        <div style={{ maxWidth: 900, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 24 }}>
          {[
            { icon: '💶', title: 'Nur bei Erfolg', desc: 'Du zahlst eine kleine Success-Fee — aber nur wenn das Fahrzeug wirklich verkauft wird.' },
            { icon: '⚡', title: 'Sofort live', desc: 'Fahrzeug hochladen, wir prüfen innerhalb von 24h, dann ist es live.' },
            { icon: '🎯', title: 'Kaufbereite Kunden', desc: 'Unsere Besucher sind auf der Suche nach Deals — keine Besichtiger, echte Käufer.' },
          ].map(b => (
            <div key={b.title} style={{ background: 'white', padding: '24px', borderRadius: 'var(--radius-lg)', border: '1px solid var(--gray-200)' }}>
              <div style={{ fontSize: '1.8rem', marginBottom: 10 }}>{b.icon}</div>
              <h3 style={{ fontWeight: 700, marginBottom: 8 }}>{b.title}</h3>
              <p style={{ color: 'var(--gray-600)', fontSize: '0.9rem', lineHeight: 1.6 }}>{b.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Form */}
      <div style={{ maxWidth: 560, margin: '0 auto', padding: '56px 24px' }}>
        {sent ? (
          <div style={{ textAlign: 'center', padding: '40px 0' }}>
            <div style={{ fontSize: '3rem', marginBottom: 16 }}>🎉</div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '2.5rem', marginBottom: 12 }}>REGISTRIERUNG ERHALTEN</h2>
            <p style={{ color: 'var(--gray-600)', lineHeight: 1.7 }}>
              Wir melden uns innerhalb von 24 Stunden bei dir. Danach kannst du sofort Fahrzeuge hochladen.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', marginBottom: 8 }}>REGISTRIERUNG</h2>
            <p style={{ color: 'var(--gray-600)', marginBottom: 32, fontSize: '0.9rem' }}>Fülle das Formular aus — wir prüfen und schalten dich frei.</p>

            {error && (
              <div style={{ background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 'var(--radius)', padding: '12px 16px', marginBottom: 20, color: '#dc2626', fontSize: '0.9rem' }}>
                {error}
              </div>
            )}

            {[
              { key: 'company_name', label: 'Firmenname', type: 'text', required: true, placeholder: 'Auto Müller GmbH' },
              { key: 'contact_name', label: 'Ansprechpartner', type: 'text', required: true, placeholder: 'Max Müller' },
              { key: 'email', label: 'E-Mail', type: 'email', required: true, placeholder: 'max@automueller.de' },
              { key: 'phone', label: 'Telefon', type: 'tel', required: false, placeholder: '+49 221 ...' },
              { key: 'city', label: 'Stadt / Region', type: 'text', required: false, placeholder: 'Köln' },
            ].map(f => (
              <div key={f.key} style={{ marginBottom: 18 }}>
                <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, marginBottom: 5, color: 'var(--gray-600)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                  {f.label} {f.required && <span style={{ color: 'var(--red)' }}>*</span>}
                </label>
                <input
                  type={f.type} required={f.required} placeholder={f.placeholder}
                  value={form[f.key]}
                  onChange={e => setForm({ ...form, [f.key]: e.target.value })}
                  style={{
                    width: '100%', padding: '11px 14px',
                    border: '1.5px solid var(--gray-200)', borderRadius: 'var(--radius)',
                    fontSize: '0.95rem', transition: 'border-color 0.2s',
                  }}
                  onFocus={e => e.target.style.borderColor = 'var(--black)'}
                  onBlur={e => e.target.style.borderColor = 'var(--gray-200)'}
                />
              </div>
            ))}

            <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center', padding: '14px', fontSize: '1rem', marginTop: 8 }} disabled={sending}>
              {sending ? 'Wird gesendet...' : 'Jetzt registrieren →'}
            </button>
            <p style={{ fontSize: '0.75rem', color: 'var(--gray-400)', marginTop: 12, textAlign: 'center' }}>
              Kostenlose Registrierung · Keine versteckten Kosten · Freischaltung innerhalb 24h
            </p>
          </form>
        )}
      </div>
    </div>
  )
}
