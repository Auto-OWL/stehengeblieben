import React, { useState } from 'react'
import { supabase } from '../lib/supabase'

const BRANDS = ['Audi', 'BMW', 'Cupra', 'Ford', 'Honda', 'Hyundai', 'Kia', 'Mazda', 'Mercedes-Benz', 'Opel', 'Peugeot', 'Porsche', 'Renault', 'Seat', 'Skoda', 'Tesla', 'Toyota', 'Volkswagen', 'Volvo', 'Andere']

export default function DealerUpload() {
  const [form, setForm] = useState({
    dealer_email: '', brand: '', model: '', variant: '', year: new Date().getFullYear(),
    mileage: 0, first_registration: '', list_price: '', sale_price: '',
    fuel_type: 'Benzin', transmission: 'Automatik', color: '', description: '', expires_at: '',
  })
  const [files, setFiles] = useState([])
  const [sent, setSent] = useState(false)
  const [sending, setSending] = useState(false)
  const [error, setError] = useState(null)
  const [step, setStep] = useState(1)

  const discount = form.list_price && form.sale_price
    ? (((form.list_price - form.sale_price) / form.list_price) * 100).toFixed(1)
    : null

  async function handleSubmit(e) {
    e.preventDefault()
    setSending(true)
    setError(null)

    // Upload images
    const imageUrls = []
    for (const file of files) {
      const filename = `${Date.now()}-${file.name}`
      const { data, error: uploadError } = await supabase.storage.from('vehicle-images').upload(filename, file)
      if (!uploadError && data) {
        const { data: urlData } = supabase.storage.from('vehicle-images').getPublicUrl(filename)
        imageUrls.push(urlData.publicUrl)
      }
    }

    // Find dealer
    const { data: dealers } = await supabase.from('dealers').select('id').eq('email', form.dealer_email).single()

    const { error: insertError } = await supabase.from('vehicles').insert({
      dealer_id: dealers?.id || null,
      brand: form.brand, model: form.model, variant: form.variant,
      year: Number(form.year), mileage: Number(form.mileage),
      first_registration: form.first_registration,
      list_price: Number(form.list_price), sale_price: Number(form.sale_price),
      fuel_type: form.fuel_type, transmission: form.transmission,
      color: form.color, description: form.description,
      images: imageUrls,
      expires_at: form.expires_at || null,
      approved: false,
    })

    setSending(false)
    if (insertError) setError('Fehler beim Hochladen. Bitte versuche es erneut.')
    else setSent(true)
  }

  const inputStyle = {
    width: '100%', padding: '11px 14px',
    border: '1.5px solid var(--gray-200)', borderRadius: 'var(--radius)',
    fontSize: '0.95rem', transition: 'border-color 0.2s', background: 'white',
  }
  const labelStyle = {
    display: 'block', fontSize: '0.78rem', fontWeight: 600,
    marginBottom: 5, color: 'var(--gray-600)',
    textTransform: 'uppercase', letterSpacing: '0.04em',
  }

  if (sent) return (
    <div style={{ paddingTop: 120, textAlign: 'center', padding: '120px 24px' }}>
      <div style={{ fontSize: '3rem', marginBottom: 16 }}>✅</div>
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '2.5rem', marginBottom: 12 }}>FAHRZEUG EINGEREICHT</h2>
      <p style={{ color: 'var(--gray-600)', maxWidth: 400, margin: '0 auto', lineHeight: 1.7 }}>
        Wir prüfen dein Fahrzeug und schalten es innerhalb von 24 Stunden frei. Du bekommst eine Bestätigung per E-Mail.
      </p>
    </div>
  )

  return (
    <div style={{ paddingTop: 64 }}>
      <div style={{ background: 'var(--black)', padding: '48px 24px' }}>
        <div style={{ maxWidth: 700, margin: '0 auto' }}>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(2.5rem, 6vw, 3.5rem)', color: 'var(--white)', marginBottom: 12 }}>
            FAHRZEUG<br /><span style={{ color: 'var(--red)' }}>EINSTELLEN</span>
          </h1>
          <p style={{ color: 'var(--gray-400)' }}>Fülle alle Felder aus — wir prüfen und schalten dein Fahrzeug innerhalb 24h frei.</p>
        </div>
      </div>

      <div style={{ maxWidth: 700, margin: '0 auto', padding: '48px 24px' }}>
        {error && (
          <div style={{ background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 'var(--radius)', padding: '12px 16px', marginBottom: 24, color: '#dc2626' }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          {/* Section: Händler */}
          <Section title="01 — Deine Kontaktdaten">
            <div>
              <label style={labelStyle}>Deine E-Mail (Händler-Konto) <span style={{ color: 'var(--red)' }}>*</span></label>
              <input type="email" required placeholder="max@autohaus.de" value={form.dealer_email}
                onChange={e => setForm({ ...form, dealer_email: e.target.value })}
                style={inputStyle} onFocus={e => e.target.style.borderColor = 'var(--black)'} onBlur={e => e.target.style.borderColor = 'var(--gray-200)'} />
            </div>
          </Section>

          {/* Section: Fahrzeugdaten */}
          <Section title="02 — Fahrzeugdaten">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div>
                <label style={labelStyle}>Marke <span style={{ color: 'var(--red)' }}>*</span></label>
                <select required value={form.brand} onChange={e => setForm({ ...form, brand: e.target.value })} style={{ ...inputStyle, cursor: 'pointer' }}>
                  <option value="">Bitte wählen</option>
                  {BRANDS.map(b => <option key={b}>{b}</option>)}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Modell <span style={{ color: 'var(--red)' }}>*</span></label>
                <input required placeholder="z.B. Golf GTI" value={form.model}
                  onChange={e => setForm({ ...form, model: e.target.value })} style={inputStyle}
                  onFocus={e => e.target.style.borderColor = 'var(--black)'} onBlur={e => e.target.style.borderColor = 'var(--gray-200)'} />
              </div>
              <div>
                <label style={labelStyle}>Variante</label>
                <input placeholder="z.B. 2.0 TSI DSG" value={form.variant}
                  onChange={e => setForm({ ...form, variant: e.target.value })} style={inputStyle}
                  onFocus={e => e.target.style.borderColor = 'var(--black)'} onBlur={e => e.target.style.borderColor = 'var(--gray-200)'} />
              </div>
              <div>
                <label style={labelStyle}>Baujahr <span style={{ color: 'var(--red)' }}>*</span></label>
                <input type="number" required min={2023} max={2025} value={form.year}
                  onChange={e => setForm({ ...form, year: e.target.value })} style={inputStyle}
                  onFocus={e => e.target.style.borderColor = 'var(--black)'} onBlur={e => e.target.style.borderColor = 'var(--gray-200)'} />
              </div>
              <div>
                <label style={labelStyle}>Erstzulassung <span style={{ color: 'var(--red)' }}>*</span></label>
                <input type="date" required value={form.first_registration}
                  onChange={e => setForm({ ...form, first_registration: e.target.value })} style={inputStyle}
                  onFocus={e => e.target.style.borderColor = 'var(--black)'} onBlur={e => e.target.style.borderColor = 'var(--gray-200)'} />
              </div>
              <div>
                <label style={labelStyle}>Kilometerstand (km)</label>
                <input type="number" min={0} max={5000} value={form.mileage}
                  onChange={e => setForm({ ...form, mileage: e.target.value })} style={inputStyle}
                  onFocus={e => e.target.style.borderColor = 'var(--black)'} onBlur={e => e.target.style.borderColor = 'var(--gray-200)'} />
              </div>
              <div>
                <label style={labelStyle}>Kraftstoff</label>
                <select value={form.fuel_type} onChange={e => setForm({ ...form, fuel_type: e.target.value })} style={{ ...inputStyle, cursor: 'pointer' }}>
                  {['Benzin', 'Diesel', 'Elektro', 'Hybrid', 'Plug-in-Hybrid'].map(f => <option key={f}>{f}</option>)}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Getriebe</label>
                <select value={form.transmission} onChange={e => setForm({ ...form, transmission: e.target.value })} style={{ ...inputStyle, cursor: 'pointer' }}>
                  {['Automatik', 'Schaltgetriebe', 'DSG', 'CVT'].map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div style={{ gridColumn: 'span 2' }}>
                <label style={labelStyle}>Farbe</label>
                <input placeholder="z.B. Midnight Blue Metallic" value={form.color}
                  onChange={e => setForm({ ...form, color: e.target.value })} style={inputStyle}
                  onFocus={e => e.target.style.borderColor = 'var(--black)'} onBlur={e => e.target.style.borderColor = 'var(--gray-200)'} />
              </div>
            </div>
          </Section>

          {/* Section: Preise */}
          <Section title="03 — Preise">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <div>
                <label style={labelStyle}>Listenpreis (€) <span style={{ color: 'var(--red)' }}>*</span></label>
                <input type="number" required min={5000} value={form.list_price}
                  onChange={e => setForm({ ...form, list_price: e.target.value })} style={inputStyle}
                  onFocus={e => e.target.style.borderColor = 'var(--black)'} onBlur={e => e.target.style.borderColor = 'var(--gray-200)'} />
              </div>
              <div>
                <label style={labelStyle}>Verkaufspreis (€) <span style={{ color: 'var(--red)' }}>*</span></label>
                <input type="number" required min={5000} value={form.sale_price}
                  onChange={e => setForm({ ...form, sale_price: e.target.value })} style={inputStyle}
                  onFocus={e => e.target.style.borderColor = 'var(--black)'} onBlur={e => e.target.style.borderColor = 'var(--gray-200)'} />
              </div>
            </div>
            {discount && (
              <div style={{ background: 'var(--gray-100)', padding: '12px 16px', borderRadius: 'var(--radius)', marginTop: 12 }}>
                <span style={{ fontSize: '0.9rem' }}>Nachlass: </span>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', color: 'var(--red)' }}>{discount}%</span>
                <span style={{ fontSize: '0.85rem', color: 'var(--gray-600)', marginLeft: 8 }}>
                  ({(form.list_price - form.sale_price).toLocaleString('de-DE')} € Ersparnis)
                </span>
              </div>
            )}
            <div style={{ marginTop: 16 }}>
              <label style={labelStyle}>Ablaufdatum (Jahres-Frist Tageszulassung)</label>
              <input type="date" value={form.expires_at}
                onChange={e => setForm({ ...form, expires_at: e.target.value })} style={inputStyle}
                onFocus={e => e.target.style.borderColor = 'var(--black)'} onBlur={e => e.target.style.borderColor = 'var(--gray-200)'} />
            </div>
          </Section>

          {/* Section: Beschreibung */}
          <Section title="04 — Beschreibung & Fotos">
            <div style={{ marginBottom: 16 }}>
              <label style={labelStyle}>Beschreibung</label>
              <textarea rows={4} value={form.description}
                onChange={e => setForm({ ...form, description: e.target.value })}
                placeholder="Ausstattung, Besonderheiten, Zustand..."
                style={{ ...inputStyle, resize: 'vertical' }}
                onFocus={e => e.target.style.borderColor = 'var(--black)'} onBlur={e => e.target.style.borderColor = 'var(--gray-200)'} />
            </div>
            <div>
              <label style={labelStyle}>Fotos hochladen</label>
              <div style={{
                border: '2px dashed var(--gray-200)', borderRadius: 'var(--radius-lg)',
                padding: '32px', textAlign: 'center', cursor: 'pointer',
                background: files.length > 0 ? 'var(--gray-100)' : 'white',
                transition: 'background 0.2s',
              }}
              onClick={() => document.getElementById('file-input').click()}
              >
                <div style={{ fontSize: '2rem', marginBottom: 8 }}>📸</div>
                <p style={{ fontSize: '0.9rem', color: 'var(--gray-600)' }}>
                  {files.length > 0 ? `${files.length} Foto(s) ausgewählt` : 'Klicken um Fotos auszuwählen'}
                </p>
                <p style={{ fontSize: '0.78rem', color: 'var(--gray-400)', marginTop: 4 }}>JPG, PNG — max. 10MB pro Bild</p>
                <input id="file-input" type="file" multiple accept="image/*"
                  style={{ display: 'none' }}
                  onChange={e => setFiles(Array.from(e.target.files))} />
              </div>
            </div>
          </Section>

          <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center', padding: '15px', fontSize: '1rem', marginTop: 8 }} disabled={sending}>
            {sending ? 'Wird hochgeladen...' : 'Fahrzeug zur Prüfung einreichen →'}
          </button>
          <p style={{ fontSize: '0.75rem', color: 'var(--gray-400)', marginTop: 12, textAlign: 'center' }}>
            Freischaltung innerhalb 24h · Du wirst per E-Mail informiert
          </p>
        </form>
      </div>
    </div>
  )
}

function Section({ title, children }) {
  return (
    <div style={{ marginBottom: 36 }}>
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', marginBottom: 20, paddingBottom: 10, borderBottom: '2px solid var(--gray-200)', letterSpacing: '0.02em' }}>
        {title}
      </h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {children}
      </div>
    </div>
  )
}
