import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import VehicleCard from '../components/VehicleCard'

const DEMO_VEHICLES = [
  { id: '1', brand: 'Volkswagen', model: 'Golf GTI', variant: '2.0 TSI DSG', year: 2024, mileage: 12, list_price: 42500, sale_price: 31900, discount_percent: 24.9, fuel_type: 'Benzin', images: [], expires_at: new Date(Date.now() + 18 * 24 * 60 * 60 * 1000) },
  { id: '2', brand: 'BMW', model: '3er', variant: '320d xDrive Touring', year: 2024, mileage: 22, list_price: 58900, sale_price: 44200, discount_percent: 24.9, fuel_type: 'Diesel', images: [], expires_at: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000) },
  { id: '3', brand: 'Tesla', model: 'Model 3', variant: 'Long Range AWD', year: 2024, mileage: 8, list_price: 54990, sale_price: 39900, discount_percent: 27.4, fuel_type: 'Elektro', images: [], expires_at: new Date(Date.now() + 12 * 24 * 60 * 60 * 1000) },
  { id: '4', brand: 'Mercedes', model: 'C-Klasse', variant: 'C220d AMG Line', year: 2024, mileage: 31, list_price: 62400, sale_price: 48500, discount_percent: 22.3, fuel_type: 'Diesel', images: [], expires_at: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000) },
  { id: '5', brand: 'Audi', model: 'A4', variant: '40 TDI S-Line', year: 2024, mileage: 18, list_price: 55100, sale_price: 41800, discount_percent: 24.1, fuel_type: 'Diesel', images: [], expires_at: new Date(Date.now() + 28 * 24 * 60 * 60 * 1000) },
  { id: '6', brand: 'Skoda', model: 'Octavia', variant: 'RS 245 Combi', year: 2024, mileage: 5, list_price: 38600, sale_price: 28400, discount_percent: 26.4, fuel_type: 'Benzin', images: [], expires_at: new Date(Date.now() + 8 * 24 * 60 * 60 * 1000) },
]

export default function Home() {
  const [vehicles, setVehicles] = useState(DEMO_VEHICLES)
  const [stats] = useState({ vehicles: 247, savings: 8400, dealers: 34 })

  useEffect(() => {
    async function load() {
      const { data } = await supabase
        .from('vehicles')
        .select('*')
        .eq('approved', true)
        .eq('sold', false)
        .order('created_at', { ascending: false })
        .limit(6)
      if (data && data.length > 0) setVehicles(data)
    }
    load()
  }, [])

  return (
    <div>
      {/* Hero */}
      <section style={{
        background: 'var(--black)',
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        padding: '120px 24px 80px',
        position: 'relative',
        overflow: 'hidden',
      }}>
        {/* Background texture */}
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(230,51,41,0.08) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(230,51,41,0.05) 0%, transparent 40%)',
          pointerEvents: 'none',
        }} />

        <div style={{ maxWidth: 1200, margin: '0 auto', width: '100%', position: 'relative' }}>
          <div style={{ maxWidth: 720 }}>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 8,
              background: 'rgba(230,51,41,0.15)',
              border: '1px solid rgba(230,51,41,0.3)',
              borderRadius: 20,
              padding: '6px 14px',
              marginBottom: 32,
            }}>
              <div style={{ width: 6, height: 6, background: 'var(--red)', borderRadius: '50%' }} />
              <span style={{ fontSize: '0.8rem', color: 'var(--red)', fontWeight: 600, letterSpacing: '0.06em' }}>
                NEUFAHRZEUGE MIT TAGESZULASSUNG
              </span>
            </div>

            <h1 style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(3.5rem, 9vw, 7rem)',
              color: 'var(--white)',
              lineHeight: 0.92,
              letterSpacing: '0.01em',
              marginBottom: 28,
            }}>
              BIS ZU 30%<br />
              <span style={{ color: 'var(--red)' }}>UNTER</span><br />
              LISTENPREIS.
            </h1>

            <p style={{
              fontSize: 'clamp(1rem, 2vw, 1.2rem)',
              color: 'var(--gray-400)',
              maxWidth: 520,
              lineHeight: 1.7,
              marginBottom: 40,
            }}>
              Langzeitsteher direkt vom Händler. Neufahrzeuge mit Tageszulassung — bis zu einem Jahr alt, bis zu 30% günstiger. Kein Umweg, kein Aufpreis.
            </p>

            <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
              <Link to="/fahrzeuge" className="btn-primary" style={{ fontSize: '1rem', padding: '14px 28px' }}>
                Jetzt Fahrzeuge entdecken →
              </Link>
              <Link to="/haendler/registrieren" className="btn-secondary" style={{
                fontSize: '1rem', padding: '14px 28px',
                color: 'var(--gray-400)', borderColor: 'rgba(255,255,255,0.15)',
              }}>
                Als Händler mitmachen
              </Link>
            </div>

            {/* Stats */}
            <div style={{
              display: 'flex', gap: 40, marginTop: 60,
              borderTop: '1px solid rgba(255,255,255,0.08)',
              paddingTop: 32, flexWrap: 'wrap',
            }}>
              {[
                { value: `${stats.vehicles}+`, label: 'Fahrzeuge verfügbar' },
                { value: `Ø ${stats.savings.toLocaleString('de-DE')} €`, label: 'Ersparnis pro Kauf' },
                { value: `${stats.dealers}`, label: 'Partnerhändler' },
              ].map(s => (
                <div key={s.label}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', color: 'var(--white)', letterSpacing: '0.02em' }}>{s.value}</div>
                  <div style={{ fontSize: '0.82rem', color: 'var(--gray-400)', marginTop: 2 }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section style={{ padding: '80px 24px', background: 'var(--gray-100)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 56 }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(2rem, 5vw, 3rem)', marginBottom: 12 }}>
              SO FUNKTIONIERT ES
            </h2>
            <p style={{ color: 'var(--gray-600)', maxWidth: 480, margin: '0 auto' }}>
              Kein Verhandeln, kein Warten. Direkt zum Deal.
            </p>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
            gap: 32,
          }}>
            {[
              { num: '01', title: 'Fahrzeug finden', desc: 'Filtere nach Marke, Preis oder Nachlass. Alle Fahrzeuge sind geprüft und sofort verfügbar.' },
              { num: '02', title: 'Anfrage senden', desc: 'Interesse? Schick direkt eine Anfrage an den Händler — kostenlos, unverbindlich.' },
              { num: '03', title: 'Deal abschliessen', desc: 'Der Händler meldet sich. Probefahrt, Kauf, fertig. Keine versteckten Gebühren.' },
            ].map(step => (
              <div key={step.num} style={{
                background: 'white',
                borderRadius: 'var(--radius-lg)',
                padding: '32px 28px',
                border: '1px solid var(--gray-200)',
              }}>
                <div style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: '3.5rem',
                  color: 'var(--red)',
                  lineHeight: 1,
                  marginBottom: 16,
                  opacity: 0.6,
                }}>
                  {step.num}
                </div>
                <h3 style={{ fontWeight: 700, marginBottom: 10, fontSize: '1.05rem' }}>{step.title}</h3>
                <p style={{ color: 'var(--gray-600)', fontSize: '0.9rem', lineHeight: 1.7 }}>{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Vehicles */}
      <section style={{ padding: '80px 24px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 40, flexWrap: 'wrap', gap: 16 }}>
            <div>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(2rem, 5vw, 3rem)', marginBottom: 8 }}>
                AKTUELLE DEALS
              </h2>
              <p style={{ color: 'var(--gray-600)' }}>Die besten Angebote – täglich aktualisiert</p>
            </div>
            <Link to="/fahrzeuge" className="btn-secondary">Alle anzeigen →</Link>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
            gap: 24,
          }}>
            {vehicles.map(v => <VehicleCard key={v.id} vehicle={v} />)}
          </div>
        </div>
      </section>

      {/* Dealer CTA */}
      <section style={{
        background: 'var(--black)',
        padding: '80px 24px',
        textAlign: 'center',
      }}>
        <div style={{ maxWidth: 640, margin: '0 auto' }}>
          <h2 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(2rem, 5vw, 3.5rem)',
            color: 'var(--white)',
            marginBottom: 20,
            lineHeight: 0.95,
          }}>
            LANGZEITSTEHER?<br />
            <span style={{ color: 'var(--red)' }}>WIR VERKAUFEN SIE.</span>
          </h2>
          <p style={{ color: 'var(--gray-400)', marginBottom: 36, fontSize: '1rem', lineHeight: 1.7 }}>
            Kein Risiko. Kein Abo. Du zahlst nur wenn wir verkaufen. Über 30 Händler vertrauen uns bereits.
          </p>
          <Link to="/haendler/registrieren" className="btn-primary" style={{ fontSize: '1rem', padding: '14px 32px' }}>
            Jetzt als Händler registrieren →
          </Link>
        </div>
      </section>
    </div>
  )
}
