import React, { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'

const DEMO = { id: '1', brand: 'Volkswagen', model: 'Golf GTI', variant: '2.0 TSI DSG', year: 2024, mileage: 12, first_registration: '2024-01-15', list_price: 42500, sale_price: 31900, discount_percent: 24.9, fuel_type: 'Benzin', transmission: 'Automatik', color: 'Tornado Rot', description: 'Tageszulassung vom 15.01.2024. Fahrzeug ist in einwandfreiem Zustand und wurde nicht privat genutzt. Vollausstattung inklusive Panoramadach, Navigationssystem, LED-Matrix und mehr.', images: [], expires_at: new Date(Date.now() + 18 * 24 * 60 * 60 * 1000), dealer_id: null }

export default function VehicleDetail() {
  const { id } = useParams()
  const [vehicle, setVehicle] = useState(null)
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({ name: '', email: '', phone: '', message: '' })
  const [sent, setSent] = useState(false)
  const [sending, setSending] = useState(false)

  useEffect(() => {
    async function load() {
      const { data } = await supabase.from('vehicles').select('*').eq('id', id).single()
      setVehicle(data || DEMO)
      setLoading(false)
    }
    load().catch(() => { setVehicle(DEMO); setLoading(false) })
  }, [id])

  async function handleInquiry(e) {
    e.preventDefault()
    setSending(true)
    const { error } = await supabase.from('inquiries').insert({
      vehicle_id: vehicle.id,
      dealer_id: vehicle.dealer_id,
      buyer_name: form.name,
      buyer_email: form.email,
      buyer_phone: form.phone,
      message: form.message,
    })
    setSending(false)
    if (!error) setSent(true)
  }

  if (loading) return <div style={{ paddingTop: 120, textAlign: 'center', color: 'var(--gray-400)' }}>Lade...</div>
  if (!vehicle) return <div style={{ paddingTop: 120, textAlign: 'center' }}>Fahrzeug nicht gefunden.</div>

  const savings = Number(vehicle.list_price) - Number(vehicle.sale_price)
  const daysLeft = vehicle.expires_at
    ? Math.ceil((new Date(vehicle.expires_at) - new Date()) / (1000 * 60 * 60 * 24))
    : null

  return (
    <div style={{ paddingTop: 64 }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '40px 24px' }}>
        {/* Back */}
        <Link to="/fahrzeuge" style={{ display: 'inline-flex', alignItems: 'center', gap: 6, color: 'var(--gray-600)', fontSize: '0.9rem', marginBottom: 28 }}>
          ← Zurück zur Übersicht
        </Link>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr minmax(320px, 380px)', gap: 48, alignItems: 'start' }}>
          {/* Left */}
          <div>
            {/* Image */}
            <div style={{
              background: 'var(--gray-100)', borderRadius: 'var(--radius-lg)',
              aspectRatio: '16/10', display: 'flex', alignItems: 'center', justifyContent: 'center',
              marginBottom: 24, overflow: 'hidden', position: 'relative',
            }}>
              {vehicle.images && vehicle.images.length > 0 ? (
                <img src={vehicle.images[0]} alt={`${vehicle.brand} ${vehicle.model}`} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                <div style={{ color: 'var(--gray-400)', textAlign: 'center' }}>
                  <div style={{ fontSize: '3rem', marginBottom: 8 }}>🚗</div>
                  <div style={{ fontSize: '0.85rem' }}>Fotos folgen</div>
                </div>
              )}
              <div style={{
                position: 'absolute', top: 16, left: 16,
                background: 'var(--red)', color: 'white',
                fontFamily: 'var(--font-display)', fontSize: '1.4rem',
                padding: '6px 14px', borderRadius: 3,
              }}>
                -{vehicle.discount_percent}%
              </div>
            </div>

            {/* Specs */}
            <h2 style={{ fontWeight: 700, marginBottom: 20, fontSize: '1.1rem' }}>Fahrzeugdaten</h2>
            <div style={{
              display: 'grid', gridTemplateColumns: '1fr 1fr',
              gap: '1px', background: 'var(--gray-200)',
              borderRadius: 'var(--radius-lg)', overflow: 'hidden',
              border: '1px solid var(--gray-200)',
            }}>
              {[
                ['Marke', vehicle.brand],
                ['Modell', vehicle.model],
                ['Variante', vehicle.variant || '—'],
                ['Baujahr', vehicle.year],
                ['Kilometerstand', `${Number(vehicle.mileage).toLocaleString('de-DE')} km`],
                ['Erstzulassung', vehicle.first_registration ? new Date(vehicle.first_registration).toLocaleDateString('de-DE') : '—'],
                ['Kraftstoff', vehicle.fuel_type || '—'],
                ['Getriebe', vehicle.transmission || '—'],
                ['Farbe', vehicle.color || '—'],
                ['Zustand', 'Tageszulassung / Neufahrzeug'],
              ].map(([key, val]) => (
                <div key={key} style={{ background: 'white', padding: '12px 16px' }}>
                  <div style={{ fontSize: '0.75rem', color: 'var(--gray-400)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 3 }}>{key}</div>
                  <div style={{ fontWeight: 500, fontSize: '0.95rem' }}>{val}</div>
                </div>
              ))}
            </div>

            {vehicle.description && (
              <div style={{ marginTop: 28 }}>
                <h2 style={{ fontWeight: 700, marginBottom: 12, fontSize: '1.1rem' }}>Beschreibung</h2>
                <p style={{ color: 'var(--gray-600)', lineHeight: 1.8, fontSize: '0.95rem' }}>{vehicle.description}</p>
              </div>
            )}
          </div>

          {/* Right - Sticky pricing + form */}
          <div style={{ position: 'sticky', top: 80 }}>
            {/* Pricing Card */}
            <div style={{
              background: 'var(--black)', borderRadius: 'var(--radius-lg)',
              padding: '28px', marginBottom: 16, color: 'var(--white)',
            }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--gray-400)', marginBottom: 4 }}>Listenpreis</div>
              <div style={{ textDecoration: 'line-through', color: 'var(--gray-400)', marginBottom: 12, fontSize: '1.1rem' }}>
                {Number(vehicle.list_price).toLocaleString('de-DE')} €
              </div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: '3rem', color: 'var(--red)', lineHeight: 1, marginBottom: 6 }}>
                {Number(vehicle.sale_price).toLocaleString('de-DE')} €
              </div>
              <div style={{ fontSize: '0.85rem', color: '#7dde7d', marginBottom: 20 }}>
                ✓ Sie sparen {savings.toLocaleString('de-DE')} € ({vehicle.discount_percent}%)
              </div>
              {daysLeft !== null && daysLeft <= 30 && (
                <div style={{
                  background: 'rgba(230,51,41,0.2)', border: '1px solid rgba(230,51,41,0.4)',
                  borderRadius: 4, padding: '8px 12px', fontSize: '0.82rem', color: 'var(--red)',
                  marginBottom: 16,
                }}>
                  ⏱ Nur noch {daysLeft} Tage verfügbar
                </div>
              )}
              <div style={{ fontSize: '0.8rem', color: 'var(--gray-400)', borderTop: '1px solid rgba(255,255,255,0.08)', paddingTop: 14 }}>
                Inkl. MwSt. · Direkt vom Händler · Keine Vermittlungsgebühr
              </div>
            </div>

            {/* Inquiry Form */}
            {sent ? (
              <div style={{
                background: '#f0fdf4', border: '1px solid #86efac',
                borderRadius: 'var(--radius-lg)', padding: 28, textAlign: 'center',
              }}>
                <div style={{ fontSize: '2rem', marginBottom: 12 }}>✅</div>
                <h3 style={{ fontWeight: 700, marginBottom: 8 }}>Anfrage gesendet!</h3>
                <p style={{ color: 'var(--gray-600)', fontSize: '0.9rem' }}>
                  Der Händler meldet sich in der Regel innerhalb von 24 Stunden bei Ihnen.
                </p>
              </div>
            ) : (
              <form onSubmit={handleInquiry} style={{
                background: 'white', borderRadius: 'var(--radius-lg)',
                padding: 28, border: '1px solid var(--gray-200)',
              }}>
                <h3 style={{ fontWeight: 700, marginBottom: 20, fontSize: '1.05rem' }}>Jetzt anfragen</h3>
                {[
                  { key: 'name', label: 'Ihr Name', type: 'text', required: true },
                  { key: 'email', label: 'E-Mail', type: 'email', required: true },
                  { key: 'phone', label: 'Telefon (optional)', type: 'tel', required: false },
                ].map(f => (
                  <div key={f.key} style={{ marginBottom: 14 }}>
                    <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, marginBottom: 5, color: 'var(--gray-600)' }}>{f.label}</label>
                    <input
                      type={f.type} required={f.required}
                      value={form[f.key]}
                      onChange={e => setForm({ ...form, [f.key]: e.target.value })}
                      style={{
                        width: '100%', padding: '10px 12px',
                        border: '1.5px solid var(--gray-200)', borderRadius: 'var(--radius)',
                        fontSize: '0.9rem', transition: 'border-color 0.2s',
                      }}
                      onFocus={e => e.target.style.borderColor = 'var(--black)'}
                      onBlur={e => e.target.style.borderColor = 'var(--gray-200)'}
                    />
                  </div>
                ))}
                <div style={{ marginBottom: 18 }}>
                  <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, marginBottom: 5, color: 'var(--gray-600)' }}>Nachricht (optional)</label>
                  <textarea
                    rows={3} value={form.message}
                    onChange={e => setForm({ ...form, message: e.target.value })}
                    placeholder="z.B. Wann ist eine Probefahrt möglich?"
                    style={{
                      width: '100%', padding: '10px 12px',
                      border: '1.5px solid var(--gray-200)', borderRadius: 'var(--radius)',
                      fontSize: '0.9rem', resize: 'vertical',
                    }}
                    onFocus={e => e.target.style.borderColor = 'var(--black)'}
                    onBlur={e => e.target.style.borderColor = 'var(--gray-200)'}
                  />
                </div>
                <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center', padding: '13px' }} disabled={sending}>
                  {sending ? 'Wird gesendet...' : 'Unverbindlich anfragen →'}
                </button>
                <p style={{ fontSize: '0.75rem', color: 'var(--gray-400)', marginTop: 10, textAlign: 'center' }}>
                  Kostenlos · Unverbindlich · Direkt zum Händler
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
