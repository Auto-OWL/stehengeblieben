import React, { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import VehicleCard from '../components/VehicleCard'

const DEMO_VEHICLES = [
  { id: '1', brand: 'Volkswagen', model: 'Golf GTI', variant: '2.0 TSI DSG', year: 2024, mileage: 12, list_price: 42500, sale_price: 31900, discount_percent: 24.9, fuel_type: 'Benzin', images: [], expires_at: new Date(Date.now() + 18 * 24 * 60 * 60 * 1000) },
  { id: '2', brand: 'BMW', model: '3er', variant: '320d xDrive Touring', year: 2024, mileage: 22, list_price: 58900, sale_price: 44200, discount_percent: 24.9, fuel_type: 'Diesel', images: [], expires_at: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000) },
  { id: '3', brand: 'Tesla', model: 'Model 3', variant: 'Long Range AWD', year: 2024, mileage: 8, list_price: 54990, sale_price: 39900, discount_percent: 27.4, fuel_type: 'Elektro', images: [], expires_at: new Date(Date.now() + 12 * 24 * 60 * 60 * 1000) },
  { id: '4', brand: 'Mercedes', model: 'C-Klasse', variant: 'C220d AMG Line', year: 2024, mileage: 31, list_price: 62400, sale_price: 48500, discount_percent: 22.3, fuel_type: 'Diesel', images: [], expires_at: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000) },
  { id: '5', brand: 'Audi', model: 'A4', variant: '40 TDI S-Line', year: 2024, mileage: 18, list_price: 55100, sale_price: 41800, discount_percent: 24.1, fuel_type: 'Diesel', images: [], expires_at: new Date(Date.now() + 28 * 24 * 60 * 60 * 1000) },
  { id: '6', brand: 'Skoda', model: 'Octavia', variant: 'RS 245 Combi', year: 2024, mileage: 5, list_price: 38600, sale_price: 28400, discount_percent: 26.4, fuel_type: 'Benzin', images: [], expires_at: new Date(Date.now() + 8 * 24 * 60 * 60 * 1000) },
  { id: '7', brand: 'Porsche', model: 'Macan', variant: 'S PDK', year: 2024, mileage: 45, list_price: 89400, sale_price: 68900, discount_percent: 22.9, fuel_type: 'Benzin', images: [], expires_at: null },
  { id: '8', brand: 'Seat', model: 'Leon', variant: 'Cupra 300 DSG', year: 2024, mileage: 9, list_price: 41200, sale_price: 30500, discount_percent: 26.0, fuel_type: 'Benzin', images: [], expires_at: null },
]

const BRANDS = ['Alle', 'Volkswagen', 'BMW', 'Mercedes', 'Audi', 'Porsche', 'Tesla', 'Skoda', 'Seat']
const FUELS = ['Alle', 'Benzin', 'Diesel', 'Elektro', 'Hybrid']
const SORT_OPTIONS = [
  { value: 'discount', label: 'Höchster Nachlass' },
  { value: 'price_asc', label: 'Preis: Niedrig → Hoch' },
  { value: 'price_desc', label: 'Preis: Hoch → Niedrig' },
  { value: 'newest', label: 'Neueste zuerst' },
]

export default function Vehicles() {
  const [vehicles, setVehicles] = useState(DEMO_VEHICLES)
  const [filtered, setFiltered] = useState(DEMO_VEHICLES)
  const [brand, setBrand] = useState('Alle')
  const [fuel, setFuel] = useState('Alle')
  const [maxPrice, setMaxPrice] = useState(100000)
  const [sort, setSort] = useState('discount')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    async function load() {
      setLoading(true)
      const { data } = await supabase
        .from('vehicles').select('*')
        .eq('approved', true).eq('sold', false)
        .order('created_at', { ascending: false })
      if (data && data.length > 0) setVehicles(data)
      setLoading(false)
    }
    load()
  }, [])

  useEffect(() => {
    let result = [...vehicles]
    if (brand !== 'Alle') result = result.filter(v => v.brand === brand)
    if (fuel !== 'Alle') result = result.filter(v => v.fuel_type === fuel)
    result = result.filter(v => Number(v.sale_price) <= maxPrice)
    if (sort === 'discount') result.sort((a, b) => b.discount_percent - a.discount_percent)
    if (sort === 'price_asc') result.sort((a, b) => a.sale_price - b.sale_price)
    if (sort === 'price_desc') result.sort((a, b) => b.sale_price - a.sale_price)
    setFiltered(result)
  }, [vehicles, brand, fuel, maxPrice, sort])

  return (
    <div style={{ paddingTop: 64 }}>
      {/* Header */}
      <div style={{ background: 'var(--black)', padding: '48px 24px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <h1 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(2.5rem, 6vw, 4.5rem)',
            color: 'var(--white)',
            letterSpacing: '0.01em',
          }}>
            ALLE FAHRZEUGE
          </h1>
          <p style={{ color: 'var(--gray-400)', marginTop: 8 }}>
            {filtered.length} Fahrzeuge verfügbar — alle mit Tageszulassung
          </p>
        </div>
      </div>

      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '32px 24px' }}>
        {/* Filters */}
        <div style={{
          display: 'flex', gap: 16, flexWrap: 'wrap',
          marginBottom: 32, alignItems: 'flex-end',
          background: 'var(--gray-100)',
          padding: '20px 24px',
          borderRadius: 'var(--radius-lg)',
        }}>
          <FilterSelect label="Marke" value={brand} onChange={setBrand} options={BRANDS} />
          <FilterSelect label="Kraftstoff" value={fuel} onChange={setFuel} options={FUELS} />
          <div>
            <label style={labelStyle}>Max. Preis: {maxPrice.toLocaleString('de-DE')} €</label>
            <input
              type="range" min={10000} max={150000} step={1000}
              value={maxPrice} onChange={e => setMaxPrice(Number(e.target.value))}
              style={{ display: 'block', width: 180, accentColor: 'var(--red)', cursor: 'pointer' }}
            />
          </div>
          <FilterSelect label="Sortierung" value={sort} onChange={setSort}
            options={SORT_OPTIONS.map(o => o.value)}
            labels={SORT_OPTIONS.map(o => o.label)}
          />
          <button
            onClick={() => { setBrand('Alle'); setFuel('Alle'); setMaxPrice(100000); setSort('discount') }}
            style={{
              background: 'none', border: '1px solid var(--gray-200)',
              padding: '9px 16px', borderRadius: 'var(--radius)',
              fontSize: '0.85rem', color: 'var(--gray-600)', cursor: 'pointer',
              alignSelf: 'flex-end',
            }}
          >
            Zurücksetzen
          </button>
        </div>

        {/* Grid */}
        {loading ? (
          <div style={{ textAlign: 'center', padding: 80, color: 'var(--gray-400)' }}>Lade Fahrzeuge...</div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 80, color: 'var(--gray-400)' }}>
            Keine Fahrzeuge mit diesen Filtern gefunden.
          </div>
        ) : (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
            gap: 24,
          }}>
            {filtered.map(v => <VehicleCard key={v.id} vehicle={v} />)}
          </div>
        )}
      </div>
    </div>
  )
}

const labelStyle = { display: 'block', fontSize: '0.78rem', fontWeight: 600, color: 'var(--gray-600)', marginBottom: 6, letterSpacing: '0.04em', textTransform: 'uppercase' }

function FilterSelect({ label, value, onChange, options, labels }) {
  return (
    <div>
      <label style={labelStyle}>{label}</label>
      <select value={value} onChange={e => onChange(e.target.value)} style={{
        padding: '9px 12px', borderRadius: 'var(--radius)',
        border: '1.5px solid var(--gray-200)',
        background: 'white', fontSize: '0.9rem',
        cursor: 'pointer', minWidth: 140,
        appearance: 'none',
        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23606060' d='M6 8L1 3h10z'/%3E%3C/svg%3E")`,
        backgroundRepeat: 'no-repeat',
        backgroundPosition: 'right 10px center',
        paddingRight: 28,
      }}>
        {options.map((opt, i) => (
          <option key={opt} value={opt}>{labels ? labels[i] : opt}</option>
        ))}
      </select>
    </div>
  )
}
