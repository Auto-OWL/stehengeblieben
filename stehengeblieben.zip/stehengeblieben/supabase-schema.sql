-- SUPABASE SCHEMA für stehengeblieben.de
-- Diesen Code in Supabase > SQL Editor ausführen

-- Händler Tabelle
CREATE TABLE dealers (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  email TEXT UNIQUE NOT NULL,
  company_name TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  phone TEXT,
  city TEXT,
  approved BOOLEAN DEFAULT FALSE
);

-- Fahrzeuge Tabelle
CREATE TABLE vehicles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  dealer_id UUID REFERENCES dealers(id) ON DELETE CASCADE,
  brand TEXT NOT NULL,
  model TEXT NOT NULL,
  variant TEXT,
  year INTEGER NOT NULL,
  mileage INTEGER DEFAULT 0,
  first_registration DATE NOT NULL,
  list_price DECIMAL(10,2) NOT NULL,
  sale_price DECIMAL(10,2) NOT NULL,
  discount_percent DECIMAL(5,2) GENERATED ALWAYS AS (
    ROUND(((list_price - sale_price) / list_price * 100), 1)
  ) STORED,
  fuel_type TEXT,
  transmission TEXT,
  color TEXT,
  description TEXT,
  images TEXT[],
  approved BOOLEAN DEFAULT FALSE,
  sold BOOLEAN DEFAULT FALSE,
  expires_at DATE
);

-- Anfragen Tabelle
CREATE TABLE inquiries (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  vehicle_id UUID REFERENCES vehicles(id) ON DELETE CASCADE,
  dealer_id UUID REFERENCES dealers(id),
  buyer_name TEXT NOT NULL,
  buyer_email TEXT NOT NULL,
  buyer_phone TEXT,
  message TEXT,
  contacted BOOLEAN DEFAULT FALSE
);

-- Row Level Security aktivieren
ALTER TABLE dealers ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE inquiries ENABLE ROW LEVEL SECURITY;

-- Policies: Jeder kann genehmigte Fahrzeuge sehen
CREATE POLICY "Approved vehicles are public"
  ON vehicles FOR SELECT
  USING (approved = TRUE AND sold = FALSE);

-- Policies: Jeder kann Anfragen erstellen
CREATE POLICY "Anyone can create inquiry"
  ON inquiries FOR INSERT
  WITH CHECK (TRUE);

-- Policies: Jeder kann Händler-Registrierung einreichen
CREATE POLICY "Anyone can register as dealer"
  ON dealers FOR INSERT
  WITH CHECK (TRUE);

-- Storage Bucket für Fahrzeugfotos
INSERT INTO storage.buckets (id, name, public)
VALUES ('vehicle-images', 'vehicle-images', TRUE);

CREATE POLICY "Anyone can view vehicle images"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'vehicle-images');

CREATE POLICY "Anyone can upload vehicle images"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'vehicle-images');
